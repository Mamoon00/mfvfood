<?php
include_once 'database.php';
$name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$city_name = $_POST['city_name'];
$email = $_POST['email'];
$autoreply="Thank you for your time, $name. Your message/comment is replied to you
below\n\n\n\nThis is an automated reply.";
$subject="Thank you for your submission $name!";
mail($email, $subject, $autoreply);
mysqli_query($conn,"insert into users (first_name,last_name,city_name,email) values ('$first_name','$last_name','$city_name','$email')") or die(mysqli_error());
?>