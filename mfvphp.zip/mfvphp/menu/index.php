<?php

	require_once "connection.php";
	
	if(isset($_REQUEST['delete_id']))
	{
		// select image from db to delete
		$id=$_REQUEST['delete_id'];	//get delete_id and store in $id variable
		
		$select_stmt= $db->prepare('SELECT * FROM product WHERE id =:id');	//sql select query
		$select_stmt->bindParam(':id',$id);
		$select_stmt->execute();
		$row=$select_stmt->fetch(PDO::FETCH_ASSOC);
		unlink("upload/".$row['product_image']); //unlink function permanently remove your file
		
		//delete an orignal record from db
		$delete_stmt = $db->prepare('DELETE FROM product WHERE id =:id');
		$delete_stmt->bindParam(':id',$id);
		$delete_stmt->execute();
		
		header("Location:index.php");
	}
	
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
<title>MFV</title>
		
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
<script src="js/jquery-1.12.4-jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
		
</head>

	<body background="https://backgroundcheckall.com/wp-content/uploads/2017/12/catering-background-5.jpg">
	
	<nav class="navbar navbar-default navbar-static-top" style="background-color:#992516;">
       <div class="navbar-fixed">
        <div class="navbar-header">
          <h4 color="White" ><a href="http://localhost/mfv"><span style="font-size:30px;color:White;">Montgomery Food Valley</a></span></h4>
		  </div>
        </div>
     
    </nav>
	
	
	<div class="wrapper">
	
	<div class="container">
			
		<div class="col-lg-12">
			<div class="col-lg-12">
                    <div class="panel panel-warning class" style="font-size:20px;color:Black;width:1100px;margin-top:70px;">
                        <div class="panel-heading" >
                           <h3 style="color:black;"><a href="add.php" style="color:black;"><span class="glyphicon glyphicon-plus" style="color:black;"></span>&nbsp; Add New Menu</a></h3>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
											<th>Price</th>
											<th>Quantity</th>
											<th>Description</th>
                                            <th>Image</th>
                                            <th>Edit</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									<?php
									$select_stmt=$db->prepare("SELECT * FROM product");	//sql select query
									$select_stmt->execute();
									while($row=$select_stmt->fetch(PDO::FETCH_ASSOC))
									{
									?>
                                        <tr>
                                            <td><?php echo $row['product_name']; ?></td>
											<td><?php echo $row['product_price']; ?></td>
											<td><?php echo $row['product_qty']; ?></td>
											<td><?php echo $row['product_category']; ?></td>
                                            <td><img src="upload/<?php echo $row['product_image']; ?>" width="150px" height="150px"></td>
                                            <td><a href="edit.php?update_id=<?php echo $row['id']; ?>" class="btn btn-warning">Edit</a></td>
                                            <td><a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger">Delete</a></td>
                                        </tr>
                                    <?php
									}
									?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
				
		</div>
		
	</div>
			
	</div>
	<footer class="text-left" >
  <div class="text-center" style="background-color:#992516; margin-top: 200px; height:60px; font-size:20px;color:White;">
    © 2021 Copyright:
	<span style="font-size:17px;">
Montgomery food Valley All right Resrved.</span>
  </div>
  <!-- Copyright -->
</footer>
									
	</body>
</html>