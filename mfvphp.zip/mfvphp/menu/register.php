<!--
//register.php
!-->

<?php
include('DatabaseConnection.php');

session_start();

$message = '';

if(isset($_SESSION['user_id']))
{
	header('location:index.php');
}

if(isset($_POST["register"]))
{   $fname = trim($_POST['fname']);
    $gender = trim($_POST['gender']);
    $age = trim($_POST['age']);
    $address = trim($_POST['address']);
	$username = trim($_POST["username"]);
	$password = trim($_POST["password"]);
	$check_query = "
	SELECT * FROM login 
	WHERE username = :username
	";
	$statement = $connect->prepare($check_query);
	$check_data = array(
		':username'		=>	$username
	);
	if($statement->execute($check_data))	
	{
		if($statement->rowCount() > 0)
		{
			$message .= '<p><label>Username already taken</label></p>';
		}
		else
		{
			if(empty($username))
			{
				$message .= '<p><label>Username is required</label></p>';
			}
			if(empty($password))
			{
				$message .= '<p><label>Password is required</label></p>';
			}
			else
			{
				if($password != $_POST['confirm_password'])
				{
					$message .= '<p><label>Password not match</label></p>';
				}
			}
			if($message == '')
			{
				$data = array(
				    ':fname'		=>	$fname,
					':gender'		=>	$gender,
					':age'		    =>	$age,
					':address'		=>	$address,
					':username'		=>	$username,
					':password'		=>	password_hash($password, PASSWORD_DEFAULT)
				);

				$query = "
				INSERT INTO login 
				(fname,gender,age,address,username, password) 
				VALUES (:fname,:gender,:age,:address,:username, :password)
				";
				$statement = $connect->prepare($query);
				if($statement->execute($data))
				{
					$message = "<label>Registration Completed</label>";
				}
			}
		}
	}
}

?>

<html>  
      <head>
    <title>Login Template</title>
    <link
      href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.materialdesignicons.com/4.8.95/css/materialdesignicons.min.css"
    />
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="assets/css/login.css" />
  </head>  
<body background="https://backgroundcheckall.com/wp-content/uploads/2017/12/restaurants-background-10.jpg">  
        <div class="container">
			<br />
			
			<h3 align="center"><span style="color:white;">Now Register Yourself as Member</span></a></h3><br />
			<br />
			<div class="panel panel-primary">
  				<div class="panel-heading" style="align:center"> <span style="color:white;"><strong>Member Registration</strong></span></div>
				<div class="panel-body">
					<form method="post">
						<span class="text-danger"><?php echo $message; ?></span>
						<div class="form-group">
							<label><span style="color:white;">Enter Full name</span></label>
							<input type="text" name="fname" class="form-control" required />
						</div>
						<div class="form-group">
							<label><span style="color:white;">Enter Your Gender</span></label>
							<input type="text" name="gender" class="form-control" required  />
						</div>
						<div class="form-group">
							<label><span style="color:white;">Enter Your Age</span></label>
							<input type="text" name="age" class="form-control" required />
						</div>
						<div class="form-group">
							<label><span style="color:white;">Enter Your Adress</span></label>
							<input type="text" name="address" class="form-control" required />
						</div>
						<div class="form-group">
							<label><span style="color:white;">Enter Username</span ></label>
							<input type="text" name="username" class="form-control" required />
						</div>
						<div class="form-group">
							<label><span style="color:white;">Enter Password</span></label>
							<input type="password" name="password" class="form-control" required />
						</div>
						<div class="form-group">
							<label><span style="color:white;">Re-enter Password</span></label>
							<input type="password" name="confirm_password" class="form-control" required />
						</div>
						
						<div class="form-group">
							<input type="submit" name="register" class="btn btn-Success" value="Register" />
						</div>
					</form>
					<div align="center">
							<button  class="btn btn-info btn-md"><a href="login.php"><span style="color:White";>Login</span></a></button>
						</div>
				</div>
			</div>
		</div>
    </body>  
</html>
