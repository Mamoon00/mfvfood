<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!-- Site Metas -->
    <title>MONTGOMERY FOOD VALLEY</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css" />
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css" />
	 <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css' />

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

<body background="https://backgroundcheckall.com/wp-content/uploads/2017/12/restaurants-background-10.jpg">
<header class="top-navbar">
      <nav class="navbar navbar-scroll navbar-expand-lg navbar-light bg-light">
        <div class="container">
          <a class="navbar-brand" href="index.html">
            <img src="images/mlogo1.png" alt="" />
          </a>
          <button
            class="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbars-rs-food"
            aria-controls="navbars-rs-food"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbars-rs-food">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/mfv/index.html">HOME</a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="index.php">MENU</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="localhost/mfv/about.html">ABOUT US</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="http://localhost/mfv/restro/index.php">RESERVATION</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="localhost/mfv/contact.html">CONTACT</a>
              </li>
        <li class="nav-item">
          <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger"></span></a>
        </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
    <!-- End header -->
 <div class="all-page-title page-breadcrumb">
      <div class="container text-center">
        <div class="row">
          <div class="col-lg-12">
            <h1>MONTGOMERY FOOD VALLEY MENU</h1>
          </div>
        </div>
      </div>
    </div>
	<br>
	<br>
	<br>
	<div class="bradcam_area breadcam_bg_5" >
        <div class="container">
            <div class="row" >
                <div class="col-xl-12" >
                    <div class="hipsum" style="background:RED">
            <div class="jumbotron">
                <h1 id="hello,-world!" align="center">Welcome to the admin Modeule Now you can Manage all functionalities as admin<a class="anchorjs-link" href="#hello,-world!"><span
                            class="anchorjs-icon"></span></a></h1>
                <p align="Center"><a href="index.php"><button type="button" class="btn btn-primary" href="index.php" align="center"> ADD ITEM </button></a></p>
                
            </div>
        </div>
                    </div>
                </div>
            </div>
        </div>
<br>
<br>
<br>
  <!-- Displaying Products Start -->
  <footer class="footer-area bg-f">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 col-md-6">
            <h3>About Us</h3>
            <p>
              We provide a wide variety of delicious taste in Pakistani,
              Turkish, Chinese Continental, Juicy Bar B Q, and Fast Food as
              well.
            </p>
          </div>
          <div class="col-lg-3 col-md-6">
            <h3>Opening hours</h3>
            <p><span class="text-color">Monday: </span>Closed</p>
            <p><span class="text-color">Tue-Wed :</span> 3:PM - 1AM</p>
            <p><span class="text-color">Thu-Fri :</span> 3:PM - 1AM</p>
            <p><span class="text-color">Sat-Sun :</span> 3:PM - 2AM</p>
          </div>
          <div class="col-lg-3 col-md-6">
            <h3>Contact information</h3>
            <p class="lead">OPPOSITE BASHARAT HOSPITAL BANDARI CHOWK SAHIWAL</p>
            <p class="lead"><a href="#">+92 300 6917422</a></p>
            <p><a href="#"> montgomeryfoodvalley@gmail.com</a></p>
          </div>
          <div class="col-lg-3 col-md-6">
            <h3>Subscribe</h3>
            <div class="subscribe_form">
              <form class="subscribe_form">
                <input
                  name="EMAIL"
                  id="subs-email"
                  class="form_input"
                  placeholder="Email Address..."
                  type="email"
                />
                <button type="submit" class="submit">SUBSCRIBE</button>
                <div class="clearfix"></div>
              </form>
            </div>
            <ul class="list-inline f-social">
              <li class="list-inline-item">
                <a href="https://www.facebook.com/montgomeryfoodvalley"
                  ><i class="fa fa-facebook" aria-hidden="true"></i
                ></a>
              </li>

              <li class="list-inline-item">
                <a
                  href="https://api.whatsapp.com/send?phone=923006917422&fbclid=IwAR3ptvBRNfywkvs_n7wm91P3rKHlGkOScVwXuPpwe4kGby1I_3U-Zi-FzCY"
                  ><i class="fa fa-whatsapp" aria-hidden="true"></i
                ></a>
              </li>
              <li class="list-inline-item">
                <a href="https://goo.gl/maps/2YvkTNscXLABiA589"
                  ><i class="fa fa-google" aria-hidden="true"></i
                ></a>
              </li>
              <li class="list-inline-item">
                <a href="https://www.instagram.com/montgomery_food_valley/"
                  ><i class="fa fa-instagram" aria-hidden="true"></i
                ></a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div class="copyright">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <p class="company-name">
                All Rights Reserved. &copy; 2021
                <a href="#">MONTGOMERY FOOD VALLEY</a> Design By :
                <a href="">MAMOON AFTAB</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  <!-- Displaying Products End -->

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script>

  <script type="text/javascript">
  $(document).ready(function() {

    // Send product details in the server
    $(".addItemBtn").click(function(e) {
      e.preventDefault();
      var $form = $(this).closest(".form-submit");
      var pid = $form.find(".pid").val();
      var pname = $form.find(".pname").val();
      var pprice = $form.find(".pprice").val();
      var pimage = $form.find(".pimage").val();
      var pcode = $form.find(".pcode").val();

      var pqty = $form.find(".pqty").val();

      $.ajax({
        url: 'action.php',
        method: 'post',
        data: {
          pid: pid,
          pname: pname,
          pprice: pprice,
          pqty: pqty,
          pimage: pimage,
          pcode: pcode
        },
        success: function(response) {
          $("#message").html(response);
          window.scrollTo(0, 0);
          load_cart_item_number();
        }
      });
    });

    // Load total no.of items added in the cart and display in the navbar
    load_cart_item_number();

    function load_cart_item_number() {
      $.ajax({
        url: 'action.php',
        method: 'get',
        data: {
          cartItem: "cart_item"
        },
        success: function(response) {
          $("#cart-item").html(response);
        }
      });
    }
  });
  
  </script>
   <!-- ALL JS FILES -->
    <script src="java/jquery-3.2.1.min.js"></script>
    <script src="java/popper.min.js"></script>
    <script src="java/bootstrap.min.js"></script>
    <script>
      $(document).ready(function () {
        $(window).scroll(function () {
          if ($(window).scrollTop() > 20) {
            $(".navbar-scroll").addClass("active");
          } else {
            $(".navbar-scroll").removeClass("active");
          }
        });
      });
    </script>
    <!-- ALL PLUGINS -->
    <script src="java/jquery.superslides.min.js"></script>
    <script src="java/images-loded.min.js"></script>
    <script src="java/isotope.min.js"></script>
    <script src="java/baguetteBox.min.js"></script>
    <script src="java/form-validator.min.js"></script>
    <script src="java/contact-form-script.js"></script>
    <script src="java/custom.js"></script>
</body>

</html>