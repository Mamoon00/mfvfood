<!--
//index.php
!-->

<?php
include('DatabaseConnection.php');

session_start();

if(!isset($_SESSION['user_id']))
{
	header("location:login.php");
}

?>

<html>  
    <head>
    <title>Login Template</title>
    <link
      href="https://fonts.googleapis.com/css?family=Karla:400,700&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.materialdesignicons.com/4.8.95/css/materialdesignicons.min.css"
    />
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
    />
    <link rel="stylesheet" href="assets/css/login.css" />
  </head> 
    <body>  
        <div class="container">
			<br />
			<h3 align="center"><span style="color:Blue";>Welcome to MFV</span></h3><br />
			<br />
				<div class="col-md-2 col-sm-3">
					<p align="Right"><h4><span style="color:#33cc33";>Asslam o Alikum </span></h4><?php echo $_SESSION['username']; ?> - <button  class="btn btn-danger btn-xs"><a href="logout.php"><span style="color:White";>Logout</span></a></button></p>
				</div>
			</div>
    </body>  
</html>

<style>

.

</style>  
<script>  
$(document).ready(function(){

	fetch_user();

	setInterval(function(){
		update_last_activity();
	}, 5000);
	function update_last_activity()
	{
		$.ajax({
			url:"update_last_activity.php",
			success:function()
			{

			}
		})
	}
</script>