<?php 

require_once 'core.php';

if($_POST) {

	

	$sql = "SELECT * FROM ordersfood";
	$query = $connect->query($sql);

	$table = '
	<table border="1" cellspacing="0" cellpadding="0" style="width:100%;">
		<tr>
			<th>Client Name</th>
			<th>Client Contact</th>
			<th>Products</th>
			<th>Grand Total</th>
		</tr>

		<tr>';
		$totalAmount = "0";
		while ($result = $query->fetch_assoc()) {
			$table .= '<tr>
				<td><center>'.$result['name'].'</center></td>
				<td><center>'.$result['phone'].'</center></td>
				<td><center>'.$result['products'].'</center></td>
				<td><center>'.$result['amount_paid'].'</center></td>
			</tr>';	
			$totalAmount += $result['amount_paid'];
		}
		$table .= '
		</tr>

		<tr>
			<td colspan="3"><center>Total Amount</center></td>
			<td><center>'.$totalAmount.'</center></td>
		</tr>
	</table>
	';	

	echo $table;

}

?>