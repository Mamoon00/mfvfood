<?php require_once 'includes/header.php'; ?>

<div class="row">
<br>
<br>
<br>
<br>
	<div class="col-md-12">
		<div class="panel panel-default" style="background-color:#f3e4c4">
			<div class="panel-heading" style="color:brown">
				<i class="glyphicon glyphicon-save-file"></i>	MVF Order Report
			</div>
			<!-- /panel-heading -->
			<div class="panel-body" style="background-color:#f3e4c4">
				
				<form class="form-horizontal" action="php_action/getOrderReport.php" method="post" id="getOrderReportForm">
				  <div class="form-group">
				    <label for="startDate" class="col-sm-2 control-label">Start Date</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="startDate" name="startDate" placeholder="Start Date" />
				    </div>
				  </div>
				  <div class="form-group">
				    <label for="endDate" class="col-sm-2 control-label">End Date</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="endDate" name="endDate" placeholder="End Date" />
				    </div>
				  </div>
				  <div class="form-group" style="margin-left:290px">
				    <div class="col-sm-offset-2 col-sm-10" >
				      <button type="submit" class="btn btn-info" id="generateReportBtn"> <i class="glyphicon glyphicon-print"></i> Generate Report</button>
				    </div>
				  </div>
				</form>

			</div>
			<!-- /panel-body -->
		</div>
	</div>
	<!-- /col-dm-12 -->
	<div class="col-md-12">
		<div class="panel panel-default" style="background-color:#f3e4c4">
			<div class="panel-heading" style="color:brown">
				<i class="glyphicon glyphicon-save-file"></i>	MVF sale Report
			</div>
			<!-- /panel-heading -->
			<div class="panel-body" style="background-color:#f3e4c4">
				
				<form class="form-horizontal" action="php_action/salereport.php" method="post" id="getsalesReportForm">
				  <div class="form-group">
				    <label for="startDate" class="col-sm-2 control-label">Start Date</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="startDate1" name="startDate1" placeholder="Start Date" />
				    </div>
				  </div>
				  <div class="form-group">
				    <label for="endDate" class="col-sm-2 control-label">End Date</label>
				    <div class="col-sm-10">
				      <input type="text" class="form-control" id="endDate1" name="endDate1" placeholder="End Date" />
				    </div>
				  </div>
				  <div class="form-group" style="margin-left:290px">
				    <div class="col-sm-offset-2 col-sm-10" >
				      <button type="submit" class="btn btn-info" id="generateReportBtn"> <i class="glyphicon glyphicon-print"></i> Generate Report</button>
				    </div>
				  </div>
				</form>

			</div>
			<!-- /panel-body -->
		</div>
	</div>	
</div>
<!-- /row -->

<script src="custom/js/report.js"></script>
<script src="custom/js/sale.js"></script>
<br>
<br>
<br>
<br>
<?php require_once 'includes/footer.php'; ?>