<?php require_once 'includes/header.php'; ?>

<?php 

$sql = "SELECT * FROM product WHERE status = 1";
$query = $connect->query($sql);
$countProduct = $query->num_rows;

$sql2 = "SELECT * FROM products ";
$query2 = $connect->query($sql2);
$countProduct2 = $query2->num_rows;


$orderSql = "SELECT * FROM orders WHERE order_status = 1";
$orderQuery = $connect->query($orderSql);
$countOrder = $orderQuery->num_rows;

$tpurchase = "0";
while ($orderResult = $orderQuery->fetch_assoc()) {
      $tpurchase += $orderResult['paid'];
}

$orderSql1 = "SELECT * FROM ordersfood ";
$orderQuery1 = $connect->query($orderSql1);
$countOrder1 = $orderQuery1->num_rows;

$tsale = "0";
while ($orderResult1 = $orderQuery1->fetch_assoc()) {
      $tsale += $orderResult1['amount_paid'];
}


$lowStockSql = "SELECT * FROM product WHERE quantity <=4 AND status = 1";
$lowStockQuery = $connect->query($lowStockSql);
$countLowStock = $lowStockQuery->num_rows;

$avStockSql = "SELECT * FROM product WHERE quantity >= 5 AND status = 1";
$avStockQuery = $connect->query($avStockSql);
$countavStock = $avStockQuery->num_rows;
$connect->close();

?>


<style type="text/css">
	.ui-datepicker-calendar {
		display: none;
	}
</style>

<!-- fullCalendar 2.2.5-->
    <link rel="stylesheet" href="assests/plugins/fullcalendar/fullcalendar.min.css">
    <link rel="stylesheet" href="assests/plugins/fullcalendar/fullcalendar.print.css" media="print">


<div class="row">
	
	<div class="col-md-12">
		<div class="card">
		  <div class="cardHeader" style="background-color:#017b5a;">
		   <h1>Calender</h1>
		    <h1><?php echo date('d'); ?></h1>
		  </div>

		  <div class="cardContainer" style="background-color:#e4eeec;">
		    <p ><?php echo date('l') .' '.date('d').', '.date('Y'); ?></p>
		  </div>
		</div> 
		<br/>

		<div class="card">
		  <div class="cardHeader" style="background-color:#245580;">
		    <h1><?php if($tpurchase) {
		    	echo $tpurchase;
		    	} else {
		    		echo '0';
		    		} ?></h1>
		  </div>

		  <div class="cardContainer" style="background-color:#e4eeec;">
		    <p> <i class="glyphicon glyphicon-rupee"></i>Total Purshased</p>
		  </div>
		</div> 
		
		</br>
        <div class="card">
		  <div class="cardHeader" style="background-color:#ff8c1a;">
		    <h1><?php if($tsale) {
		    	echo $tsale;
		    	} else {
		    		echo '0';
		    		} ?></h1>
		  </div>

		  <div class="cardContainer" style="background-color:#e4eeec;">
		    <p> <i class="glyphicon glyphicon-rupee"></i>Total sale</p>
		  </div>
		</div> 
	</div>

	<div class="col-md-8">
		<div class="panel panel-default">	
		</div>
	
	</div>
<div class="col-md-6">
		<div class="panel panel-danger">
			<div class="panel-heading">
				
				<a href="product.php" style="text-decoration:none;color:Red;">
					<strong>Total No of Items</strong>
					<span class="badge pull pull-right"><?php echo $countProduct; ?></span>	
				</a>
				
			</div> 
		</div> 
	</div> 
<div class="col-md-6">
		<div class="panel panel-danger">
			<div class="panel-heading">
				
				<a href="product.php" style="text-decoration:none;color:Red;">
					<strong>Total Menu Items </strong>
					<span class="badge pull pull-right"><?php echo $countProduct2; ?></span>	
				</a>
				
			</div> 
		</div> 
	</div> 
		<div class="col-md-6">
			<div class="panel panel-info">
			<div class="panel-heading">
				<a href="orders.php?o=manord" style="text-decoration:none;color:Blue;">
					<strong>No of Item Purchased</strong>
					<span class="badge pull pull-right"><?php echo $countOrder; ?></span>
				</a>
					
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
		</div> 
		
		<div class="col-md-6">
			<div class="panel panel-info">
			<div class="panel-heading">
				<a href="orders.php?o=manord" style="text-decoration:none;color:Blue;">
					<strong>No of Order Placed</strong>
					<span class="badge pull pull-right"><?php echo $countOrder1; ?></span>
				</a>
					
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
		</div>

	<div class="col-md-6">
		<div class="panel panel-success">
			<div class="panel-heading">
				<a href="product.php" style="text-decoration:none;color:green;">
					<strong>Stock Required</strong>
					<span class="badge pull pull-right"><?php echo $countLowStock; ?></span>	
				</a>
				
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
	</div> <!--/col-md-4-->
	
	<div class="col-md-6">
		<div class="panel panel-success">
			<div class="panel-heading">
				<a href="product.php" style="text-decoration:none;color:green;">
					<strong>Stock Available</strong>
					<span class="badge pull pull-right"><?php echo $countavStock; ?></span>	
				</a>
				
			</div> <!--/panel-hdeaing-->
		</div> <!--/panel-->
	</div> <!--/col-md-4-->
	
</div> <!--/row-->

<!-- fullCalendar 2.2.5 -->
<script src="assests/plugins/moment/moment.min.js"></script>
<script src="assests/plugins/fullcalendar/fullcalendar.min.js"></script>


<script type="text/javascript">
	$(function () {
			// top bar active
	$('#navDashboard').addClass('active');

      //Date for the calendar events (dummy data)
      var date = new Date();
      var d = date.getDate(),
      m = date.getMonth(),
      y = date.getFullYear();

      $('#calendar').fullCalendar({
        header: {
          left: '',
          center: 'title'
        },
        buttonText: {
          today: 'today',
          month: 'month'          
        }        
      });


    });
</script>
<?php require_once 'includes/footer.php'; ?>